package Actions;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;

public class Exe implements ActionListener {

    public void actionPerformed(ActionEvent e) {


        try {
            Process p = Runtime.getRuntime().exec(new String[]{"C:\\Users\\nloud\\Documents\\Curse\\Minecraft\\Install\\minecraft.exe"});
        } catch (IOException var4) {
            ;
        }
    }
}
